<?php
    /**
     * Your Twitter App Info
     */
    
     // Consumer Key
    define('CONSUMER_KEY', 'cLAunr8uxbdZWeKZL36jDVpF1');
    define('CONSUMER_SECRET', 'WWkVwLxFaAKxPcTLOwb2oOxSZEtkOXOA5loYW1a9oE870oJuLV');

    // User Access Token
    define('ACCESS_TOKEN', '3062307642-QmRUXmQjPlsjg3pw7VqVDnfguVxkZ4C7Al8w1Ju');
    define('ACCESS_SECRET', 'j5QHlOsetB56YGN3kPaANBhgI0IWVSxRCO1hocLgyfb4g');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));